#include <iostream>
#include <string>

using namespace std;

class sumsing
{
public:
    sumsing(std::string s)
    {
        s_ = s;
    }
    std::string s_;

    sumsing()
    {

    }

    sumsing& operator = (const sumsing& other)
    {
        this->s_ = other.s_;
        return *this;
    }

    void numara()
    {
        int nr = 0;
        int nrlit = 0;
        string x = *this->s_;

        for(int i=0; i < x.length; i++)
            if((x[i] >= "0") && (x[i] <= "9"))
                nr++;
            else
                if(((x[i] >= "A") && (x[i] <= "Z")) || ((x[i] >= "a") && (x[i] <= "z")))
                    nrlit++;
        cout<< endl << nr << "numere" << endl << nrlit << "litere" << endl;
    }
};



int main()
{
    sumsing a ("12fg");
    sumsing b;

    b = a;

    cout<<b.s_;
    numara();
}
