#include<iostream>
#include<string>
#include<utility>

class Stringuri
{
	std::string sir;
	int cif=0;
	int lit=0;
	int i=0,j=0;
	int n;
	int m=cifre.length();
	std::string x;
	std::string cifre="0123456789";
	public:
	void Set(std::string s)
	{
		sir=s;
		n=sir.length();
		//std::cout<<n;
	}
	Stringuri& operator= (const Stringuri & s)
	{
		this->sir=s.sir;
		return *this;
	}
    Stringuri& operator= (Stringuri && s)
	{
		this->sir=s.sir;
		return *this;
		s.sir="";
	}
	void Cif()
	{
		//std::cout<<sir;
		for(i=0;i<n;i++)
            for(j=0;j<m;j++)
                if(cifre[j]==sir[i])
                    cif++;
                else
                    lit++;
        std::cout<<"In sirul introdus sunt:"<<cif<<"cifre"<<"si"<<lit<<"litere\n";
	}
};
int main()
{
    std::string sirul1,sirul2;
    std::cout<< "Introduceti sirul: \n";
    std::cin>>sirul1;
    std::cout<<"Inainte de mutare! \n";
    std::cout<<sirul1<<"\n";
    sirul2=std::move(sirul1);
    std::cout<<"Sirul in care s-a mutat \n";
    std::cout<<sirul2<<"\n";
    std::cout<<"Dupa mutare! \n";
    std::cout<<sirul1;
    //Stringuri st;
    //st.Set(sirul2);
    //st.Cif();
    return 0;
}
